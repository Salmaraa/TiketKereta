package com.example.tiketkereta

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import java.util.Calendar

class belitiket : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_belitiket)

        // Mendapatkan tanggal dan jam awal dari DatePicker dan TimePicker
        val calendar = Calendar.getInstance()
        datepick.init(
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ) { _, year, month, day ->
            calendar.set(year, month, day)
        }

        timePicker.setOnTimeChangedListener { _, hourOfDay, minute ->
            calendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
            calendar.set(Calendar.MINUTE, minute)
        }

        // Menangani saat tombol "Beli Tiket" ditekan
        btnBuyTicket.setOnClickListener {
            val selectedDate = SimpleDateFormat("MM/dd/yyyy", Locale.US).format(calendar.time)
            val selectedTime = SimpleDateFormat("HH:mm", Locale.US).format(calendar.time)

            // Di sini Anda dapat menggunakan selectedDate dan selectedTime sesuai kebutuhan Anda
            // Misalnya, menyimpannya ke database atau menampilkan kepada pengguna
        }
    }
}